//Evan Altshule
#include "word.h"
#include <iostream>
#include "itemtype.h"
#include "list.h"
using namespace std;

// constructors
word_container::word_container(){
  file_head = NULL;
  file_tail = NULL;
}

word::word(){
  f_word="";
  file_data = new list();
}

word::word(const string f_word){
  this -> f_word = f_word;
  file_data = new list();
}

// observers
string word::get_Word(){
  return f_word;
}
list* word::get_flist(){
  return file_data;
}


void word_container::word_append(const word* file_data){
  word_node* temp = file_head;
  word_node* node_word = new word_node(*file_data, NULL, NULL);
  if(file_head==NULL){
          file_head = node_word;
          file_head = node_word;
          return;
        }
  if(temp->data().get_Word() >= node_word->data().get_Word()){
    temp->set_prev(node_word);
    node_word->set_next(temp);
    file_head= node_word;
  }
  else{
    while(node_word->data().get_Word() > temp->data().get_Word() && temp->next() != NULL){
      temp= temp-> next();
    }
    if(temp->next()!=NULL){
      node_word->set_next(temp);
      node_word->set_prev(temp->prev());
      temp->prev()->set_next(node_word);
      temp->set_prev(node_word);
    }
    else if(temp->next() == NULL && node_word->data().get_Word()>temp->data().get_Word()){
          node_word->set_prev(temp);
          temp->set_next(node_word);
          file_tail = node_word;
        }
        else if(temp->next()==NULL && node_word->data().get_Word() <temp->data().get_Word()){
          temp->set_prev(node_word);
          temp->prev()->set_next(node_word);
          node_word->set_next(temp);
          node_word->set_prev(temp->prev());

        }
    }
  }




