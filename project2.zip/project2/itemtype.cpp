//evanaltshule
#include <iostream>
#include <string>
#include "itemtype.h"
using namespace std;


file::file(const string fname, const int& num) {
  file_name = fname; 
  file_count = num;  
}


void file::increase_file_count(){
  file_count++;   
}
void file::set_filename(string fname){

  file_name = fname;
}
void file::set_file_count(int i){
  file_count=i;
}

string file::get_filename() const {
  return file_name;   
}
int file::get_count() {
  return file_count;    
}


void file::print() {
  cout << file_name << ": " << file_count << endl;
}


