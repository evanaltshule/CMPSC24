//evan altshule
#ifndef LIST_H
#define LIST_H

#include <cassert>
#include <cstdlib>
#include <iostream>
#include "itemtype.h"
#include <string>

using namespace std;


struct list_node
{
public:
	list_node(file*& d, list_node* l=NULL, list_node* p=NULL)
    {
        data_f = d;
        next_f = l;
        prev_f = p;
    }

    //modifiers

    void set_data(file* d) {data_f = d;}
    void set_next(list_node* l) {next_f = l;}
    void set_prev(list_node* p) {prev_f = p;}

    // observers
    file* data() const {return data_f;}

    // forward links
    list_node* next() {return next_f;}
    const list_node* next() const {return next_f;}

    // backward links
    list_node* prev() {return prev_f;}
    const list_node* prev() const {return prev_f;}

private:
    file* data_f;
    // forward pointer
    list_node* next_f;
    // backward pointer
    list_node* prev_f;
};

class list
{
public: 
	//constructors 
	list();

	void file_append(const string *filename);
    void file_switch(list_node* filename);

	list_node* get_head(){return head_f;}
	list_node* get_tail(){return tail_f;}

private: 
	list_node* head_f;
	list_node* tail_f;
};



#endif

