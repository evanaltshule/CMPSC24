//evan altshule
#ifndef ITEMTYPE_H
#define ITEMTYPE_H
#include <cstdlib>
#include <string>
#include <iostream>
using namespace std;

class file{
public:
  // constructor
  file(const string fname= "", const int& num=0);

  // modifiers
  void increase_file_count();
  void set_filename(string fname);
  void set_file_count(int i);

  // observers
  string get_filename() const;
  int get_count();
  void print();
  
private:
  string file_name;
  int file_count;
};
#endif
