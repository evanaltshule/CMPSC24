//evan altshule
#ifndef WORDSEARCHUNION_H
#define WORDSEARCHUNION_H
#include <sys/types.h>
#include <dirent.h>
#include <errno.h>
#include <vector>
#include <string>
#include <iostream>
#include <fstream>

using namespace std;

class wordsearchunion{
public:
	//error checking
	static int getdir (string dir, vector<string> &files);
};

#endif