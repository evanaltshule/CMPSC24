//evan altshule
#ifndef WORDSEARCHCOUNT_H
#define WORDSEARCHCOUNT_H
#include <sys/types.h>
#include <dirent.h>
#include <errno.h>
#include <vector>
#include <string>
#include <iostream>
#include <fstream>

using namespace std;

class wordsearchcount{
public:
	//error checking
	static int getdir (string dir, vector<string> &files);
};

#endif