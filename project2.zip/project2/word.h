//evan altshule
#ifndef WORD_H
#define WORD_H
#include <iostream>
#include <string>
#include "list.h"
#include "itemtype.h"
using namespace std;

class word
{
public:
  //constructors
  word();
  word(const string input);

  //observers
  list* get_flist();
  string get_Word();
        

  void set_word(const string f_word, const string file_title);

private:
  string f_word;
  list* file_data;
};

struct word_node
{
public:
	word_node(const word& d, word_node* l=NULL, word_node* p=NULL)
    {
        data_f = d;
        next_f = l;
        prev_f = p;
    }

    //modifiers

    void set_data(word d) {data_f = d;}
    void set_next(word_node* l) {next_f = l;}
    void set_prev(word_node* p) {prev_f = p;}

    // observers
     word data() const {return data_f;}

    // forward links
    word_node* next() {return next_f;}
    const word_node* next() const {return next_f;}

    // backward links
    word_node* prev() {return prev_f;}
    const word_node* prev() const {return prev_f;}

private:
    word data_f;
    // forward pointer
    word_node* next_f;
    // backward pointer
    word_node* prev_f;
};

class word_container
{
  public:
    //constructor
    word_container();
    //observers
    word_node* get_head(){return file_head;}
    word_node* get_tail(){return file_tail;}
    //modifiers
    void word_append(const word* file_data);
  private:
    word_node* file_head;
    word_node* file_tail;
};
#endif
