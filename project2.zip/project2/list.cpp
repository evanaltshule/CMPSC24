//evan altshule
#include "list.h"
#include <cassert>
#include <cstdlib>
#include <string>
#include "itemtype.h"
#include "word.h"

using namespace std;

list::list(){
	head_f = NULL;
	tail_f = NULL;
}

void list::file_append(const string *filename){

	list_node *cursor = head_f;
	while (cursor != NULL){
		if (cursor->data()->get_filename() == *filename){
			cursor->data()->increase_file_count();
		list_node *new_cursor = head_f;
		//sort function goes here
		while(new_cursor->next() != NULL){
			new_cursor = new_cursor -> next();
		}
		tail_f = new_cursor;
		return;
		}
		cursor=cursor->next();
	}
	cursor = head_f;
	if(cursor == NULL){
		file* temp_file = new file(*filename, 1);
		list_node* temp_fnode = new list_node(temp_file, NULL, NULL);
		head_f = tail_f = temp_fnode;
	}
	else {
		file* temp_file = new file(*filename, 1);
		list_node* temp_fnode = new list_node(temp_file, NULL, NULL);
		while(cursor ->next() != NULL)
		{
			cursor = cursor ->next();
		}
		cursor -> set_next(temp_fnode);
		temp_fnode-> set_prev(cursor);
		temp_fnode -> set_next(NULL);
	}
	return;

	
}
