//evan altshule
#include <sys/types.h>
#include <dirent.h>
#include <errno.h>
#include <vector>
#include <string>
#include <iostream>
#include <fstream>
#include "itemtype.h"
#include "word.h"
#include "wordsearchcount.h"
#include "list.h"

using namespace std;
//error checking
int wordsearchcount::getdir (string dir, vector<string> &files)
{
  DIR *dp;
  struct dirent *dirp;
  if((dp  = opendir(dir.c_str())) == NULL) {
    cout << "Error(" << errno << ") opening " << dir << endl;
    return errno;
  }
  
  while ((dirp = readdir(dp)) != NULL) {
    files.push_back(string(dirp->d_name));
  }
  closedir(dp);
  return 0;
}

int main(int argc, char* argv[])
{
  string dir; 
  vector<string> files = vector<string>();
  //reads in command line arguments
  if (argc < 2)
    {
      cout << "No Directory specified; Exiting ..." << endl;
      return(-1);
    }
  dir = string(argv[1]);
  if (wordsearchcount::getdir(dir,files)!=0)
    {
      cout << "Error opening " << dir << "; Exiting ..." << endl;
      return(-2);    }
  
  word_container* w_list = new word_container();
  string slash("/");
  for (unsigned int i = 0; i < files.size(); i++) {
    if(files[i][0]=='.')continue; //skip hidden files
    ifstream fin((string(argv[1])+slash+files[i]).c_str()); //open using absolute path
    // ...read the file...
    string current_word;
    while(true){
      fin>>current_word;
      if(fin.eof()) {
        break;
      }
      else {
        // Now the string "input" holds the keyword, and the string "files[i]" holds the document name.
        // looks for "input" in word_list, if exists adds "files[i]" to array
        word_node *temp= w_list->get_head(); 
        
        while (temp != NULL){ 
            if (temp->data().get_Word()==current_word){
                temp->data().get_flist()->file_append(&files[i]);
                break;
            }
            temp=temp->next();
        }
        if(temp==NULL) {
          word* new_word = new word(current_word);
          new_word->get_flist()->file_append(&files[i]);
          w_list->word_append(new_word);
               } 

                }
        }
    fin.close();
  }
  string search_word;
  int threshold;
  word_node * temp_node= w_list->get_head();
  while(temp_node != NULL){

    temp_node = temp_node->next();
  }


  cout << "Enter word: ";
  cin >> search_word;
  cout << "Enter threshold: ";
  cin >> threshold;

  temp_node= w_list->get_head();
  if(temp_node==NULL){
      cout << "word not existent" << endl;
  }

  while(temp_node!=NULL){
      if (temp_node->data().get_Word() == search_word){
        list_node* fnode =temp_node->data().get_flist()->get_head();
        while(fnode!=NULL){
          if(fnode->data()->get_count() >= threshold){ 
             fnode->data()->print(); 
                 } 
          fnode=fnode->next();
        }
        break;
      }
      temp_node=temp_node->next();
  }
  

  return 0;

}



